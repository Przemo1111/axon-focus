import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  RefreshControl,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '@/src/context/AuthContext';
import { getBlockedSites, addBlockedSite, removeBlockedSite, BlockedSite } from '@/src/services/api';

export default function SettingsScreen() {
  const { user, signOut } = useAuth();
  const [blockedSites, setBlockedSites] = useState<BlockedSite[]>([]);
  const [newSiteUrl, setNewSiteUrl] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  const loadBlockedSites = useCallback(async () => {
    if (!user) return;
    try {
      const sites = await getBlockedSites(user.user_id);
      setBlockedSites(sites);
    } catch (error) {
      console.error('Error loading blocked sites:', error);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadBlockedSites();
  }, [loadBlockedSites]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadBlockedSites();
    setRefreshing(false);
  }, [loadBlockedSites]);

  const handleAddSite = async () => {
    if (!user || !newSiteUrl.trim()) return;

    // Simple URL validation
    let url = newSiteUrl.trim().toLowerCase();
    if (!url.includes('.')) {
      Alert.alert('Invalid URL', 'Please enter a valid website URL');
      return;
    }

    // Remove protocol if present
    url = url.replace(/^(https?:\/\/)?(www\.)?/, '');

    setIsAdding(true);
    try {
      const newSite = await addBlockedSite(user.user_id, url);
      setBlockedSites([...blockedSites, newSite]);
      setNewSiteUrl('');
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to add site');
    } finally {
      setIsAdding(false);
    }
  };

  const handleRemoveSite = (site: BlockedSite) => {
    Alert.alert(
      'Remove Site',
      `Remove ${site.site_url} from blocked list?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              await removeBlockedSite(site.id);
              setBlockedSites(blockedSites.filter((s) => s.id !== site.id));
            } catch (error) {
              Alert.alert('Error', 'Failed to remove site');
            }
          },
        },
      ]
    );
  };

  const handleSignOut = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: signOut,
        },
      ]
    );
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins} minutes`;
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#6366F1"
            />
          }
        >
          {/* Header */}
          <Text style={styles.title}>Settings</Text>

          {/* Profile Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Profile</Text>
            <View style={styles.profileCard}>
              <View style={styles.avatarLarge}>
                <Ionicons name="person" size={40} color="#6366F1" />
              </View>
              <View style={styles.profileInfo}>
                <Text style={styles.profileName}>{user?.display_name}</Text>
                <Text style={styles.profileEmail}>{user?.email}</Text>
                <View style={styles.profileStats}>
                  <View style={styles.profileStat}>
                    <Ionicons name="time" size={16} color="#22D3EE" />
                    <Text style={styles.profileStatText}>
                      {formatTime(user?.total_focus_time || 0)} total
                    </Text>
                  </View>
                  <View style={styles.profileStat}>
                    <Ionicons name="flame" size={16} color="#F59E0B" />
                    <Text style={styles.profileStatText}>
                      {user?.streak_days || 0} day streak
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </View>

          {/* Block List Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Block List</Text>
              <Ionicons name="shield" size={20} color="#6366F1" />
            </View>
            <Text style={styles.sectionDescription}>
              Add websites to block during focus sessions
            </Text>

            {/* Add New Site */}
            <View style={styles.addSiteContainer}>
              <TextInput
                style={styles.input}
                placeholder="e.g., twitter.com"
                placeholderTextColor="#64748B"
                value={newSiteUrl}
                onChangeText={setNewSiteUrl}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="url"
              />
              <TouchableOpacity
                style={[
                  styles.addButton,
                  (!newSiteUrl.trim() || isAdding) && styles.addButtonDisabled,
                ]}
                onPress={handleAddSite}
                disabled={!newSiteUrl.trim() || isAdding}
              >
                <Ionicons
                  name="add"
                  size={24}
                  color={!newSiteUrl.trim() || isAdding ? '#64748B' : '#fff'}
                />
              </TouchableOpacity>
            </View>

            {/* Blocked Sites List */}
            {blockedSites.length > 0 ? (
              <View style={styles.blockedList}>
                {blockedSites.map((site) => (
                  <View key={site.id} style={styles.blockedItem}>
                    <Ionicons name="globe-outline" size={20} color="#94A3B8" />
                    <Text style={styles.blockedUrl}>{site.site_url}</Text>
                    <TouchableOpacity
                      onPress={() => handleRemoveSite(site)}
                      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                    >
                      <Ionicons name="close-circle" size={24} color="#EF4444" />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            ) : (
              <View style={styles.emptyBlockList}>
                <Ionicons name="shield-checkmark-outline" size={32} color="#64748B" />
                <Text style={styles.emptyBlockText}>No blocked sites yet</Text>
              </View>
            )}
          </View>

          {/* App Info */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>About</Text>
            <View style={styles.infoCard}>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>App Version</Text>
                <Text style={styles.infoValue}>1.0.0</Text>
              </View>
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Authentication</Text>
                <View style={styles.mockBadge}>
                  <Text style={styles.mockBadgeText}>MOCK</Text>
                </View>
              </View>
            </View>
          </View>

          {/* Sign Out Button */}
          <TouchableOpacity
            style={styles.signOutButton}
            onPress={handleSignOut}
            activeOpacity={0.7}
          >
            <Ionicons name="log-out-outline" size={24} color="#EF4444" />
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0D0D1A',
  },
  flex: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#F8FAFC',
    marginBottom: 24,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#F8FAFC',
    marginBottom: 12,
  },
  sectionDescription: {
    fontSize: 14,
    color: '#64748B',
    marginBottom: 16,
  },
  profileCard: {
    flexDirection: 'row',
    backgroundColor: '#13132B',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
  },
  avatarLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(99, 102, 241, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#F8FAFC',
  },
  profileEmail: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 4,
  },
  profileStats: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 12,
  },
  profileStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  profileStatText: {
    fontSize: 12,
    color: '#94A3B8',
  },
  addSiteContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  input: {
    flex: 1,
    backgroundColor: '#13132B',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#1E1E3F',
  },
  addButton: {
    width: 52,
    height: 52,
    backgroundColor: '#6366F1',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButtonDisabled: {
    backgroundColor: '#1E1E3F',
  },
  blockedList: {
    backgroundColor: '#13132B',
    borderRadius: 12,
    overflow: 'hidden',
  },
  blockedItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#1E1E3F',
    gap: 12,
  },
  blockedUrl: {
    flex: 1,
    fontSize: 16,
    color: '#F8FAFC',
  },
  emptyBlockList: {
    alignItems: 'center',
    padding: 32,
    backgroundColor: '#13132B',
    borderRadius: 12,
  },
  emptyBlockText: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 8,
  },
  infoCard: {
    backgroundColor: '#13132B',
    borderRadius: 12,
    padding: 16,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: '#94A3B8',
  },
  infoValue: {
    fontSize: 14,
    color: '#F8FAFC',
  },
  mockBadge: {
    backgroundColor: 'rgba(245, 158, 11, 0.2)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  mockBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#F59E0B',
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    paddingVertical: 16,
    borderRadius: 16,
    gap: 10,
    marginTop: 8,
  },
  signOutText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#EF4444',
  },
});
