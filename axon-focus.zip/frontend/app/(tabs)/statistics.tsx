import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '@/src/context/AuthContext';
import { getWeeklyStats, getUserSessions, WeeklyStats, FocusSession } from '@/src/services/api';
import { BarChart } from 'react-native-gifted-charts';

const screenWidth = Dimensions.get('window').width;

export default function StatisticsScreen() {
  const { user, refreshUser } = useAuth();
  const [weeklyStats, setWeeklyStats] = useState<WeeklyStats[]>([]);
  const [recentSessions, setRecentSessions] = useState<FocusSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    if (!user) return;
    try {
      const [weekly, sessions] = await Promise.all([
        getWeeklyStats(user.user_id),
        getUserSessions(user.user_id, 7),
      ]);
      setWeeklyStats(weekly);
      setRecentSessions(sessions.slice(0, 5));
      await refreshUser();
    } catch (error) {
      console.error('Error loading statistics:', error);
    } finally {
      setIsLoading(false);
    }
  }, [user, refreshUser]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }, [loadData]);

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getWeeklyTotal = () => {
    return weeklyStats.reduce((sum, day) => sum + day.minutes, 0);
  };

  const getAverageDaily = () => {
    if (weeklyStats.length === 0) return 0;
    return Math.round(getWeeklyTotal() / 7);
  };

  const chartData = weeklyStats.map((day) => ({
    value: day.minutes,
    label: day.day,
    frontColor: day.minutes >= 30 ? '#6366F1' : '#3B3B5F',
    topLabelComponent: () => (
      <Text style={styles.chartTopLabel}>{day.minutes > 0 ? day.minutes : ''}</Text>
    ),
  }));

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6366F1" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#6366F1"
          />
        }
      >
        {/* Header */}
        <Text style={styles.title}>Focus Statistics</Text>

        {/* Summary Cards */}
        <View style={styles.summaryRow}>
          <View style={styles.summaryCard}>
            <Ionicons name="time-outline" size={24} color="#6366F1" />
            <Text style={styles.summaryValue}>
              {formatTime(user?.total_focus_time || 0)}
            </Text>
            <Text style={styles.summaryLabel}>Total Focus</Text>
          </View>
          <View style={styles.summaryCard}>
            <Ionicons name="calendar-outline" size={24} color="#22D3EE" />
            <Text style={styles.summaryValue}>{formatTime(getWeeklyTotal())}</Text>
            <Text style={styles.summaryLabel}>This Week</Text>
          </View>
          <View style={styles.summaryCard}>
            <Ionicons name="trending-up-outline" size={24} color="#22C55E" />
            <Text style={styles.summaryValue}>{formatTime(getAverageDaily())}</Text>
            <Text style={styles.summaryLabel}>Daily Avg</Text>
          </View>
        </View>

        {/* Weekly Chart */}
        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Weekly Overview</Text>
          <Text style={styles.chartSubtitle}>Minutes focused per day</Text>
          <View style={styles.chartContainer}>
            <BarChart
              data={chartData}
              barWidth={32}
              spacing={16}
              roundedTop
              roundedBottom
              xAxisThickness={0}
              yAxisThickness={0}
              yAxisTextStyle={{ color: '#64748B', fontSize: 10 }}
              xAxisLabelTextStyle={{ color: '#94A3B8', fontSize: 12 }}
              noOfSections={4}
              maxValue={Math.max(...weeklyStats.map((d) => d.minutes), 60)}
              hideRules
              backgroundColor="transparent"
              isAnimated
              height={150}
              width={screenWidth - 80}
            />
          </View>
          <View style={styles.chartLegend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#6366F1' }]} />
              <Text style={styles.legendText}>Goal met (30+ min)</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#3B3B5F' }]} />
              <Text style={styles.legendText}>Below goal</Text>
            </View>
          </View>
        </View>

        {/* Recent Sessions */}
        <Text style={styles.sectionTitle}>Recent Sessions</Text>
        {recentSessions.length > 0 ? (
          <View style={styles.sessionsList}>
            {recentSessions.map((session) => (
              <View key={session.id} style={styles.sessionItem}>
                <View style={styles.sessionIcon}>
                  <Ionicons name="checkmark-circle" size={24} color="#22C55E" />
                </View>
                <View style={styles.sessionInfo}>
                  <Text style={styles.sessionDuration}>
                    {formatTime(session.duration)} focus session
                  </Text>
                  <Text style={styles.sessionDate}>
                    {formatDate(session.date)}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#64748B" />
              </View>
            ))}
          </View>
        ) : (
          <View style={styles.emptyState}>
            <Ionicons name="hourglass-outline" size={48} color="#64748B" />
            <Text style={styles.emptyText}>No sessions yet</Text>
            <Text style={styles.emptySubtext}>
              Start your first focus session to see statistics!
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0D0D1A',
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#0D0D1A',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#F8FAFC',
    marginBottom: 24,
  },
  summaryRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: '#13132B',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#F8FAFC',
    marginTop: 8,
  },
  summaryLabel: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 4,
  },
  chartCard: {
    backgroundColor: '#13132B',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#F8FAFC',
    marginBottom: 4,
  },
  chartSubtitle: {
    fontSize: 14,
    color: '#64748B',
    marginBottom: 20,
  },
  chartContainer: {
    alignItems: 'center',
    marginVertical: 10,
  },
  chartTopLabel: {
    color: '#94A3B8',
    fontSize: 10,
    marginBottom: 4,
  },
  chartLegend: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 24,
    marginTop: 16,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  legendText: {
    fontSize: 12,
    color: '#94A3B8',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#F8FAFC',
    marginBottom: 16,
  },
  sessionsList: {
    backgroundColor: '#13132B',
    borderRadius: 16,
    overflow: 'hidden',
  },
  sessionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#1E1E3F',
  },
  sessionIcon: {
    marginRight: 12,
  },
  sessionInfo: {
    flex: 1,
  },
  sessionDuration: {
    fontSize: 16,
    fontWeight: '500',
    color: '#F8FAFC',
  },
  sessionDate: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 2,
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
    backgroundColor: '#13132B',
    borderRadius: 16,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#F8FAFC',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 8,
    textAlign: 'center',
  },
});
