import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '@/src/context/AuthContext';
import { getTodayStats, TodayStats } from '@/src/services/api';

const DURATION_OPTIONS = [
  { minutes: 25, label: '25 min', description: 'Pomodoro' },
  { minutes: 45, label: '45 min', description: 'Deep Work' },
  { minutes: 60, label: '60 min', description: 'Marathon' },
];

export default function DashboardScreen() {
  const { user, refreshUser } = useAuth();
  const router = useRouter();
  const [todayStats, setTodayStats] = useState<TodayStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedDuration, setSelectedDuration] = useState(25);

  const loadData = useCallback(async () => {
    if (!user) return;
    try {
      const stats = await getTodayStats(user.user_id);
      setTodayStats(stats);
      await refreshUser();
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  }, [user, refreshUser]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }, [loadData]);

  const handleStartSession = () => {
    router.push({
      pathname: '/focus-session',
      params: { duration: selectedDuration.toString() },
    });
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6366F1" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#6366F1"
          />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Welcome back,</Text>
            <Text style={styles.userName}>{user?.display_name || 'User'}</Text>
          </View>
          <View style={styles.avatarContainer}>
            <Ionicons name="person" size={24} color="#6366F1" />
          </View>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsRow}>
          {/* Today's Focus */}
          <View style={[styles.statCard, styles.primaryCard]}>
            <Ionicons name="time" size={28} color="#22D3EE" />
            <Text style={styles.statValue}>
              {formatTime(todayStats?.total_minutes || 0)}
            </Text>
            <Text style={styles.statLabel}>Today's Focus</Text>
          </View>

          {/* Streak */}
          <View style={[styles.statCard, styles.secondaryCard]}>
            <Ionicons name="flame" size={28} color="#F59E0B" />
            <Text style={styles.statValue}>{user?.streak_days || 0}</Text>
            <Text style={styles.statLabel}>Day Streak</Text>
          </View>
        </View>

        {/* Sessions Today */}
        <View style={styles.sessionsCard}>
          <View style={styles.sessionsHeader}>
            <Ionicons name="checkmark-circle" size={24} color="#22C55E" />
            <Text style={styles.sessionsText}>
              {todayStats?.session_count || 0} sessions completed today
            </Text>
          </View>
          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                {
                  width: `${Math.min(
                    ((todayStats?.total_minutes || 0) / 120) * 100,
                    100
                  )}%`,
                },
              ]}
            />
          </View>
          <Text style={styles.progressText}>
            {todayStats?.total_minutes || 0}/120 min daily goal
          </Text>
        </View>

        {/* Duration Selector */}
        <Text style={styles.sectionTitle}>Choose Duration</Text>
        <View style={styles.durationContainer}>
          {DURATION_OPTIONS.map((option) => (
            <TouchableOpacity
              key={option.minutes}
              style={[
                styles.durationOption,
                selectedDuration === option.minutes &&
                  styles.durationOptionSelected,
              ]}
              onPress={() => setSelectedDuration(option.minutes)}
              activeOpacity={0.7}
            >
              <Text
                style={[
                  styles.durationLabel,
                  selectedDuration === option.minutes &&
                    styles.durationLabelSelected,
                ]}
              >
                {option.label}
              </Text>
              <Text
                style={[
                  styles.durationDesc,
                  selectedDuration === option.minutes &&
                    styles.durationDescSelected,
                ]}
              >
                {option.description}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Start Button */}
        <TouchableOpacity
          style={styles.startButton}
          onPress={handleStartSession}
          activeOpacity={0.8}
        >
          <Ionicons name="play" size={28} color="#fff" />
          <Text style={styles.startButtonText}>Start Focus Session</Text>
        </TouchableOpacity>

        {/* Tip */}
        <View style={styles.tipCard}>
          <Ionicons name="bulb" size={20} color="#F59E0B" />
          <Text style={styles.tipText}>
            Complete 30 minutes of focus daily to maintain your streak!
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0D0D1A',
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#0D0D1A',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  greeting: {
    fontSize: 14,
    color: '#94A3B8',
  },
  userName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#F8FAFC',
  },
  avatarContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(99, 102, 241, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    padding: 20,
    borderRadius: 20,
    alignItems: 'center',
  },
  primaryCard: {
    backgroundColor: 'rgba(34, 211, 238, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(34, 211, 238, 0.2)',
  },
  secondaryCard: {
    backgroundColor: 'rgba(245, 158, 11, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(245, 158, 11, 0.2)',
  },
  statValue: {
    fontSize: 28,
    fontWeight: '700',
    color: '#F8FAFC',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 14,
    color: '#94A3B8',
    marginTop: 4,
  },
  sessionsCard: {
    backgroundColor: '#13132B',
    borderRadius: 16,
    padding: 16,
    marginBottom: 24,
  },
  sessionsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sessionsText: {
    fontSize: 14,
    color: '#F8FAFC',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#1E1E3F',
    borderRadius: 4,
    marginBottom: 8,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#6366F1',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    color: '#64748B',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#F8FAFC',
    marginBottom: 16,
  },
  durationContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  durationOption: {
    flex: 1,
    padding: 16,
    borderRadius: 16,
    backgroundColor: '#13132B',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  durationOptionSelected: {
    borderColor: '#6366F1',
    backgroundColor: 'rgba(99, 102, 241, 0.15)',
  },
  durationLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: '#F8FAFC',
  },
  durationLabelSelected: {
    color: '#6366F1',
  },
  durationDesc: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 4,
  },
  durationDescSelected: {
    color: '#8B5CF6',
  },
  startButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#6366F1',
    paddingVertical: 18,
    borderRadius: 20,
    gap: 12,
    marginBottom: 24,
  },
  startButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
  tipCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: 'rgba(245, 158, 11, 0.1)',
    padding: 16,
    borderRadius: 12,
  },
  tipText: {
    flex: 1,
    fontSize: 14,
    color: '#F59E0B',
  },
});
