import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Animated,
  Dimensions,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '@/src/context/AuthContext';
import { useFocusStore } from '@/src/store/focusStore';
import { startFocusSession, endFocusSession } from '@/src/services/api';

const { width, height } = Dimensions.get('window');

export default function FocusSessionScreen() {
  const { duration } = useLocalSearchParams<{ duration: string }>();
  const router = useRouter();
  const { user, refreshUser } = useAuth();
  const { setSession, clearSession, currentSessionId, remainingSeconds, updateRemainingSeconds } = useFocusStore();

  const [isPaused, setIsPaused] = useState(false);
  const [isSessionStarted, setIsSessionStarted] = useState(false);
  const [showBreakSuggestion, setShowBreakSuggestion] = useState(false);

  const pulseAnim = useRef(new Animated.Value(1)).current;
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const plannedDuration = parseInt(duration || '25', 10);

  useEffect(() => {
    initSession();
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (isSessionStarted && !isPaused) {
      startPulseAnimation();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isSessionStarted, isPaused]);

  const initSession = async () => {
    if (!user) return;

    try {
      const session = await startFocusSession(user.user_id, plannedDuration);
      setSession(session.id, plannedDuration);
      setIsSessionStarted(true);
      startTimer();
    } catch (error) {
      console.error('Error starting session:', error);
      Alert.alert('Error', 'Failed to start focus session');
      router.back();
    }
  };

  const startPulseAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  const startTimer = () => {
    intervalRef.current = setInterval(() => {
      updateRemainingSeconds(useFocusStore.getState().remainingSeconds - 1);
    }, 1000);
  };

  useEffect(() => {
    if (remainingSeconds <= 0 && isSessionStarted) {
      handleSessionComplete();
    }
  }, [remainingSeconds]);

  const handleSessionComplete = async () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    if (currentSessionId) {
      try {
        await endFocusSession(currentSessionId, plannedDuration);
        await refreshUser();
      } catch (error) {
        console.error('Error ending session:', error);
      }
    }

    clearSession();
    setShowBreakSuggestion(true);
  };

  const handleEndSession = () => {
    Alert.alert(
      'End Session?',
      'Are you sure you want to end your focus session early?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'End Session',
          style: 'destructive',
          onPress: async () => {
            if (intervalRef.current) {
              clearInterval(intervalRef.current);
            }

            const elapsedMinutes = Math.floor(
              (plannedDuration * 60 - remainingSeconds) / 60
            );

            if (currentSessionId && elapsedMinutes > 0) {
              try {
                await endFocusSession(currentSessionId, elapsedMinutes);
                await refreshUser();
              } catch (error) {
                console.error('Error ending session:', error);
              }
            }

            clearSession();
            router.back();
          },
        },
      ]
    );
  };

  const handlePauseResume = () => {
    if (isPaused) {
      startTimer();
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }
    setIsPaused(!isPaused);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgress = () => {
    const totalSeconds = plannedDuration * 60;
    return ((totalSeconds - remainingSeconds) / totalSeconds) * 100;
  };

  if (showBreakSuggestion) {
    return (
      <View style={styles.container}>
        <View style={styles.completedContainer}>
          <View style={styles.successIcon}>
            <Ionicons name="checkmark-circle" size={80} color="#22C55E" />
          </View>
          <Text style={styles.completedTitle}>Great Work!</Text>
          <Text style={styles.completedSubtitle}>
            You completed a {plannedDuration} minute focus session
          </Text>

          <View style={styles.breakCard}>
            <Ionicons name="cafe" size={32} color="#F59E0B" />
            <Text style={styles.breakTitle}>Take a Break</Text>
            <Text style={styles.breakText}>
              Rest for 5-10 minutes before your next session
            </Text>
          </View>

          <TouchableOpacity
            style={styles.doneButton}
            onPress={() => router.back()}
            activeOpacity={0.8}
          >
            <Text style={styles.doneButtonText}>Done</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Background gradient effect */}
      <View style={styles.backgroundGlow} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={handleEndSession}
          style={styles.closeButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="close" size={28} color="#94A3B8" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Deep Focus Mode</Text>
        <View style={styles.placeholder} />
      </View>

      {/* Timer Display */}
      <View style={styles.timerSection}>
        <Animated.View
          style={[
            styles.timerCircle,
            { transform: [{ scale: pulseAnim }] },
          ]}
        >
          <View style={styles.timerInner}>
            <Text style={styles.timerText}>{formatTime(remainingSeconds)}</Text>
            <Text style={styles.timerLabel}>
              {isPaused ? 'Paused' : 'Remaining'}
            </Text>
          </View>
          {/* Progress ring */}
          <View style={styles.progressRing}>
            <View
              style={[
                styles.progressFill,
                {
                  transform: [{ rotate: `${(getProgress() / 100) * 360}deg` }],
                },
              ]}
            />
          </View>
        </Animated.View>

        {/* Session Info */}
        <View style={styles.sessionInfo}>
          <View style={styles.infoPill}>
            <Ionicons name="time-outline" size={16} color="#6366F1" />
            <Text style={styles.infoText}>{plannedDuration} min session</Text>
          </View>
        </View>
      </View>

      {/* Controls */}
      <View style={styles.controls}>
        <TouchableOpacity
          style={styles.pauseButton}
          onPress={handlePauseResume}
          activeOpacity={0.8}
        >
          <Ionicons
            name={isPaused ? 'play' : 'pause'}
            size={32}
            color="#fff"
          />
          <Text style={styles.pauseButtonText}>
            {isPaused ? 'Resume' : 'Pause'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.endButton}
          onPress={handleEndSession}
          activeOpacity={0.7}
        >
          <Ionicons name="stop" size={24} color="#EF4444" />
          <Text style={styles.endButtonText}>End Session</Text>
        </TouchableOpacity>
      </View>

      {/* Focus Tips */}
      <View style={styles.tipsContainer}>
        <Ionicons name="bulb-outline" size={18} color="#64748B" />
        <Text style={styles.tipText}>
          Stay focused! Blocked sites are disabled during this session.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0D0D1A',
  },
  backgroundGlow: {
    position: 'absolute',
    top: height * 0.2,
    left: width * 0.1,
    width: width * 0.8,
    height: width * 0.8,
    borderRadius: width * 0.4,
    backgroundColor: 'rgba(99, 102, 241, 0.1)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  closeButton: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#F8FAFC',
  },
  placeholder: {
    width: 44,
  },
  timerSection: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  timerCircle: {
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: 'rgba(99, 102, 241, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 4,
    borderColor: 'rgba(99, 102, 241, 0.3)',
  },
  timerInner: {
    alignItems: 'center',
  },
  timerText: {
    fontSize: 64,
    fontWeight: '200',
    color: '#F8FAFC',
    fontVariant: ['tabular-nums'],
  },
  timerLabel: {
    fontSize: 16,
    color: '#64748B',
    marginTop: 8,
  },
  progressRing: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderRadius: 140,
  },
  progressFill: {
    position: 'absolute',
    top: -4,
    left: '50%',
    width: 8,
    height: 20,
    backgroundColor: '#6366F1',
    borderRadius: 4,
    marginLeft: -4,
  },
  sessionInfo: {
    marginTop: 32,
  },
  infoPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(99, 102, 241, 0.15)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#94A3B8',
  },
  controls: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    gap: 16,
  },
  pauseButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#6366F1',
    paddingVertical: 18,
    borderRadius: 20,
    gap: 12,
  },
  pauseButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  endButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    paddingVertical: 16,
    borderRadius: 16,
    gap: 8,
  },
  endButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#EF4444',
  },
  tipsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingBottom: 40,
    gap: 8,
  },
  tipText: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
  },
  // Completed state styles
  completedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  successIcon: {
    marginBottom: 24,
  },
  completedTitle: {
    fontSize: 32,
    fontWeight: '700',
    color: '#F8FAFC',
    marginBottom: 8,
  },
  completedSubtitle: {
    fontSize: 16,
    color: '#94A3B8',
    textAlign: 'center',
    marginBottom: 40,
  },
  breakCard: {
    backgroundColor: 'rgba(245, 158, 11, 0.1)',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    width: '100%',
    marginBottom: 40,
  },
  breakTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#F59E0B',
    marginTop: 12,
  },
  breakText: {
    fontSize: 14,
    color: '#94A3B8',
    textAlign: 'center',
    marginTop: 8,
  },
  doneButton: {
    backgroundColor: '#6366F1',
    paddingVertical: 18,
    paddingHorizontal: 60,
    borderRadius: 20,
  },
  doneButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
});
